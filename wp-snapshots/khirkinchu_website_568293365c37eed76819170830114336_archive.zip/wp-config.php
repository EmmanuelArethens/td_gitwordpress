<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordp');

/** MySQL database username */
define('DB_USER', 'manu');

/** MySQL database password */
define('DB_PASSWORD', 'manuesttropcool');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '^Wv5;5c{yXw~95go.)[fYmwJEVp{WGo1I5ht1NWTyT`| goY8(/X+Mz6i<:>p-yH');
define('SECURE_AUTH_KEY',  'M)j]mgWGS_4oXg{e(~w<O}UMG?X`m}KD0G*EsOxRX Tcs0^8L78#_}DwcQ2P%)jT');
define('LOGGED_IN_KEY',    'O.H1sA @l~iMO8-!MQ*eWmVZZt>pEPvg-v/T._j6kFh8C;GpPBWfw@L]Qn2Za_>!');
define('NONCE_KEY',        'Kq$C>/)-i8a5:f]DjJF cm(,P;mNFo5{mPXl%/{8%G+kO>$.H<Dk6ZU>{lLZl+?_');
define('AUTH_SALT',        'V6-M]!&@/n:CwH.-GmSqzer`Xbpi61(r./=|=~GuG>=*VQ{JwVnKAeKC%()km[to');
define('SECURE_AUTH_SALT', '}+h($( 3ivqPI4?7/VM?zZclK/?QpxZ-FDZF9;~6hcuP72r_SnL7rh9`X!^J:UC9');
define('LOGGED_IN_SALT',   '(r{wm*C{tvSiGpjbfM<VXfDSO6pu%1&1]+zD-~P&X1C.:6a($O`pu@8+E(=siZEk');
define('NONCE_SALT',       'ax<M#=IL91fRhD[a-Zdzb%RFLX?T<!qAh:p]}seb<!9z%,.df<BBb/8JUr<_NCzG');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

define('FS_METHOD', 'direct');
